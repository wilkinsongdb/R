# Criando gr�ficos com ggplo2 para an�lise de aluguel di�rios de bicicletas em cada esta��o do ano!

setwd("C:/Users/wilki/OneDrive/Documentos/Wilkinson/Cursos/DSA/Visualiza��o de Dados e Design de Dashboards/R")
getwd()


# Instalando e carregando o pacote
install.packages("ggplot2")
library(ggplot2)

#Colocando gr�ficos lado a lado na �rea de desenho

######## Usando Base Plotting System #########

# Carregando dados

bikes <- read.csv("2-03-ggplot2/bikes.csv")
head(bikes)
str(bikes)
bikes$season <- factor(bikes$season, levels = c(1,2,3,4), labels = c("Primavera", "Ver�o", "Outono", "Inverno"))
attach(bikes)
head(bikes$season)

# Dividindo  a �rea de desenho em 4 sub-�reas
par(mfrow = c(2,2))


#Coletando amostra de dados

primavera <- subset(bikes, season == "Primavera")$cnt
verao <- subset(bikes, season == "Ver�o")$cnt
outono <- subset(bikes, season == "Outono")$cnt
inverno <- subset(bikes, season == "Inverno")$cnt

#Desenhando os gr�ficos
hist(primavera, probability = TRUE, xlab = "Aluguel Di�rio na Primavera", main = "")
lines(density(primavera))

hist(verao, probability = TRUE, xlab = "Aluguel Di�rio no Ver�o", main = "")
lines(density(verao))

hist(outono, probability = TRUE, xlab = "Aluguel Di�rio na Outono", main = "")
lines(density(outono))

hist(inverno, probability = TRUE, xlab = "Aluguel Di�rio na Inverno", main = "")
lines(density(inverno))

## Usando ggplot2
qplot(cnt, data = bikes) + facet_wrap(~ season, nrow = 2) + geom_histogram(fill = "blue")
qplot(cnt, data = bikes, fill = season)

#Plots multivariados
bikes <- read.csv("2-03-ggplot2/bikes.csv")
bikes$season <- factor(bikes$season, levels = c(1,2,3,4), labels = c("Primavera", "Ver�o", "Outono", "Inverno"))
bikes$weathersit <- factor(bikes$weathersit, levels = c(1,2,3), labels = c("Sol", "Nublado", "Chuva"))
bikes$windspeed <- cut(bikes$windspeed, breaks = 3, labels = c("Baixo", "M�dio", "Alto"))
bikes$weekday<- factor(bikes$weekday, levels = c(0:6), labels = c("DOm", "Seg", "Ter", "Quar", "Qui", "Sex", "Sab"))
attach(bikes)

#Criando o o bjeto plot
plot <- ggplot(bikes, aes(temp, cnt))

#Adicionando camadas ao plot
plot + geom_point(size = 3,
                  aes(color = factor(windspeed))) +
  geom_smooth(method = "lm", se = FALSE, col = "red") +
  facet_grid(weekday ~ season) + 
  theme(legend.position = "bottom")



